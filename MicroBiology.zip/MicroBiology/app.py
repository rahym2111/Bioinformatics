import os
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, jsonify, flash
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = "uploads"
ALLOWED_EXTENSIONS = {"pdb", "ent", "txt"}

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["SECRET_KEY"] = "change-this-secret"  # production-da üýtgetmeli

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def parse_seqres_from_pdb(filepath):
    """
    Ýönekeý PDB SEQRES parser: SEQRES setirlerinden amino-acid sequence çykarýar.
    Ähli chainleri birleşdirip ýazýar.
    """
    seqs = {}
    try:
        with open(filepath, "r") as f:
            for line in f:
                if line.startswith("SEQRES"):
                    # PDB format: cols contain chain id at column 11 (index 10)
                    parts = line.split()
                    # format example: ['SEQRES', '1', 'A', '50', 'MET', 'GLY', ...]
                    if len(parts) >= 5:
                        chain = parts[2]
                        residues = parts[4:]
                        seqs.setdefault(chain, []).extend(residues)
    except Exception as e:
        return {}
    # join residues for each chain
    return {chain: " ".join(res) for chain, res in seqs.items()}

@app.route("/")
def index():
    files = sorted(os.listdir(app.config["UPLOAD_FOLDER"]))
    return render_template("index.html", files=files)

@app.route("/upload", methods=["POST"])
def upload():
    if "file" not in request.files:
        flash("Faýl tapylmady.")
        return redirect(url_for("index"))
    file = request.files["file"]
    if file.filename == "":
        flash("Faýl atyny giriziň.")
        return redirect(url_for("index"))
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        save_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(save_path)
        flash(f"{filename} üstünlikli ýüklendi.")
        return redirect(url_for("viewer", filename=filename))
    else:
        flash("Rugsat berilmedik faýl görnüşi.")
        return redirect(url_for("index"))

@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename, as_attachment=False)

@app.route("/viewer/<path:filename>")
def viewer(filename):
    # parse sequence for display
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    seqs = {}
    if os.path.exists(filepath):
        seqs = parse_seqres_from_pdb(filepath)
    return render_template("viewer.html", filename=filename, sequences=seqs)

@app.route("/api/files")
def api_files():
    files = sorted(os.listdir(app.config["UPLOAD_FOLDER"]))
    return jsonify(files)

@app.route("/api/seq/<path:filename>")
def api_seq(filename):
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    if not os.path.exists(filepath):
        return jsonify({"error": "not found"}), 404
    seqs = parse_seqres_from_pdb(filepath)
    return jsonify(seqs)

if __name__ == "__main__":
    app.run(debug=True)
