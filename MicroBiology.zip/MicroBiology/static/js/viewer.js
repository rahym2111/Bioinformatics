// viewer.js
// depends on NGL (included in viewer.html)
// provides initNGLViewer(pdbPath)

function initNGLViewer(pdbPath) {
  // create Stage in the viewport-inner div
  const stage = new NGL.Stage("viewport-inner", { backgroundColor: "white" });

  // Resize handling (NGL needs this)
  window.addEventListener("resize", function () {
    stage.handleResize();
  }, false);

  // load the structure from the uploaded file URL
  stage.loadFile(pdbPath).then(function (component) {
    // default representation
    component.addRepresentation("cartoon", { sele: "protein", colorScheme: "chainname" });
    component.addRepresentation("licorice", { sele: "hetero or (sidechain and not hydrogen)", multipleBond: true, visible: false });

    stage.autoView();

    // allow rep switching
    const repSelect = document.getElementById("rep-select");
    repSelect.addEventListener("change", function (evt) {
      const val = evt.target.value;
      component.removeAllRepresentations();
      if (val === "cartoon") {
        component.addRepresentation("cartoon", { sele: "protein", colorScheme: "chainname" });
      } else if (val === "cartoon+licorice") {
        component.addRepresentation("cartoon", { sele: "protein", colorScheme: "chainname" });
        component.addRepresentation("licorice", { sele: "not protein", visible: true });
      } else if (val === "ball+stick") {
        component.addRepresentation("ball+stick", { sele: "all" });
      } else if (val === "surface") {
        component.addRepresentation("surface", { sele: "protein", opacity: 0.8, colorScheme: "residueindex" });
      } else if (val === "backbone") {
        component.addRepresentation("backbone", { sele: "protein" });
      } else {
        component.addRepresentation("cartoon", { sele: "protein", colorScheme: "chainname" });
      }
    });

    // Reset button
    const resetBtn = document.getElementById("reset-btn");
    resetBtn.addEventListener("click", function () {
      stage.autoView();
    });

    // Screenshot
    const screenshotBtn = document.getElementById("screenshot-btn");
    screenshotBtn.addEventListener("click", function () {
      stage.makeImage({ factor: 1, antialias: true }).then(function (blob) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "ngl_screenshot.png";
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
      });
    });

  }).catch(function (err) {
    console.error("Failed to load PDB:", err);
    alert("PDB faýlyny ýüklerimde säwlik boldy. Konsolda görkez.");
  });
}
