from flask import Flask, render_template, request, jsonify
import numpy as np

app = Flask(__name__)

def logistic_growth(N0, r, K, t):
    return K / (1 + ((K - N0)/N0) * np.exp(-r*t))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/simulate', methods=['POST'])
def simulate():
    data = request.json
    N0 = float(data.get('initial_population', 100))
    temp = float(data.get('temperature', 37))
    pH = float(data.get('ph', 7))
    antibiotic = float(data.get('antibiotic', 0))

    K = 1000
    r = 0.4
    r *= 1 - 0.01 * abs(temp - 37)
    r *= 1 - 0.1 * abs(pH - 7)
    r -= 0.05 * antibiotic

    t = np.linspace(0, 24, 100)
    N = logistic_growth(N0, r, K, t).tolist()

    return jsonify({"time": t.tolist(), "population": N})

if __name__ == "__main__":
    app.run(debug=True)
