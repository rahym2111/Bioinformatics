let chart;

function simulate() {
    const initial_population = document.getElementById('initial_population').value;
    const temperature = document.getElementById('temperature').value;
    const ph = document.getElementById('ph').value;
    const antibiotic = document.getElementById('antibiotic').value;

    fetch('/simulate', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({initial_population, temperature, ph, antibiotic})
    })
    .then(response => response.json())
    .then(data => {
        const ctx = document.getElementById('growthChart').getContext('2d');
        if(chart) chart.destroy();

        // X oýnaýjylary 1-den 24-e çenli doly san hökmünde düzmek
        let hours = [];
        for(let i=1; i<=24; i++){
            hours.push(i);
        }

        // data.population arrayi 100 nokatdan ibarət, ony 24 nokada azaltmak üçin sampling
        let sampledPopulation = [];
        for(let i=0; i<24; i++){
            let index = Math.floor(i * (data.population.length / 24));
            sampledPopulation.push(data.population[index]);
        }

        chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: hours,
                datasets: [{
                    label: 'Bakteriýa sany',
                    data: sampledPopulation,
                    borderColor: '#e74c3c',
                    backgroundColor: 'rgba(231, 76, 60, 0.2)',
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: true } },
                scales: {
                    x: { title: { display: true, text: 'Wagt (sagat)' } },
                    y: { title: { display: true, text: 'Populýasiýa' } }
                }
            }
        });
    });
}
